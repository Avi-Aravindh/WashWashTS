Freebie: Clothing Icons (9 Styles, AI, EPS, SVG, PNG)

This freebie has been brought to you by SmashingMagazine.com. 

The icon set was created and designed by the Creativebin team (http://www.creativebin.com/) exclusively for Smashing Magazine and its readers, and cannot be sold, redistributed or modified and reposted. However, icons can be used in both private and commercial projects.


- - - - - - - - - - - - - - - - - -

Dearest Smashing reader,

Thank you for downloading this icon set. All icons are royalty-free. You can use them in your commercial as well as your personal works. You may modify the size, color or shape of the icons. No attribution is required. However, reselling of bundles or individual pictograms is prohibited. 

You may make one copy of the assets solely for backup or archival purposes or transfer the assets to a single hard drive, provided that you keep the original and accompanying documentation in your possession. You may enter projects into contests, film festivals, publications and or exhibitions that use the assets in the permitted listed methods.

The icons may not be resold, sub-licensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites other than SmashingMagazine.com. Please link to the article in which this freebie was released if you would like to spread the word: https://www.smashingmagazine.com/2017/01/freebie-clothing-icons-9-styles-ai-eps-svg-png



Sincerely yours,
The Smashing Magazine Team
www.smashingmagazine.com